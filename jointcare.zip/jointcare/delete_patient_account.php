<?php
header("Content-Type: application/json; charset=utf-8");

// 🔹 Include DB connection
require_once "db_connect.php";

// 🔹 Read JSON input
$input = json_decode(file_get_contents("php://input"), true);

if (!isset($input["patient_id"]) || empty($input["patient_id"])) {
    echo json_encode([
        "success" => false,
        "message" => "Patient ID is required"
    ]);
    exit;
}

$patient_id = trim($input["patient_id"]);

// 🔹 Check if patient exists
$check = $conn->prepare("SELECT patient_id FROM patients WHERE patient_id = ?");
$check->bind_param("s", $patient_id);
$check->execute();
$result = $check->get_result();

if ($result->num_rows === 0) {
    echo json_encode([
        "success" => false,
        "message" => "No account found"
    ]);
    $check->close();
    $conn->close();
    exit;
}
$check->close();

// 🔹 Delete patient account
$delete = $conn->prepare("DELETE FROM patients WHERE patient_id = ?");
$delete->bind_param("s", $patient_id);

if ($delete->execute()) {
    echo json_encode([
        "success" => true,
        "message" => "Account deleted successfully"
    ]);
} else {
    echo json_encode([
        "success" => false,
        "message" => "Failed to delete account"
    ]);
}

$delete->close();
$conn->close();
?>
