<?php
require_once "db_connect.php";
header("Content-Type: application/json; charset=UTF-8");

$data = json_decode(file_get_contents("php://input"), true);

$patient_id = trim($data["patient_id"] ?? "");
$name = trim($data["name"] ?? "");
$dose = trim($data["dose"] ?? "");
$route = trim($data["route"] ?? "");
$frequency_number = trim($data["frequency_number"] ?? "");
$frequency_text = trim($data["frequency_text"] ?? "");
$duration = trim($data["duration"] ?? "");

if (
    $patient_id === "" || $name === "" || $dose === "" ||
    $route === "" || $frequency_number === "" ||
    $frequency_text === "" || $duration === ""
) {
    echo json_encode([
        "success" => false,
        "message" => "Missing parameters"
    ]);
    exit;
}

$stmt = $conn->prepare(
    "DELETE FROM treatments
     WHERE patient_id = ?
     AND name = ?
     AND dose = ?
     AND route = ?
     AND frequency_number = ?
     AND frequency_text = ?
     AND duration = ?"
);

$stmt->bind_param(
    "sssssss",
    $patient_id,
    $name,
    $dose,
    $route,
    $frequency_number,
    $frequency_text,
    $duration
);

$stmt->execute();

if ($stmt->affected_rows > 0) {
    echo json_encode([
        "success" => true,
        "message" => "Treatment deleted"
    ]);
} else {
    echo json_encode([
        "success" => false,
        "message" => "No matching treatment found"
    ]);
}

$stmt->close();
$conn->close();
