<?php
header("Content-Type: application/json");
require_once "db_config.php";

try {
    $data = json_decode(file_get_contents("php://input"), true);

    if (!$data || empty($data["patient_id"])) {
        throw new Exception("patient_id missing");
    }

    $patient_id = trim($data["patient_id"]);

    $stmt = $mysqli->prepare("
        SELECT
            medicine_name AS name,
            dose,
            route,
            frequency_number,
            frequency_text,
            duration_weeks AS duration
        FROM treatments
        WHERE patient_id = ?
        ORDER BY created_at DESC
    ");

    if (!$stmt) {
        throw new Exception($mysqli->error);
    }

    $stmt->bind_param("s", $patient_id);
    $stmt->execute();

    $res = $stmt->get_result();
    $rows = [];

    while ($row = $res->fetch_assoc()) {
        $rows[] = $row;
    }

    echo json_encode([
        "success" => true,
        "count" => count($rows),
        "treatments" => $rows
    ]);

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "error" => $e->getMessage()
    ]);
}
