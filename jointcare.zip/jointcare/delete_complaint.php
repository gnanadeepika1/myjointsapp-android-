<?php
header("Content-Type: application/json; charset=UTF-8");
require_once "db_connect.php";

$data = json_decode(file_get_contents("php://input"), true);

$patient_id = $data['patient_id'] ?? '';
$title      = $data['title'] ?? '';

if (empty($patient_id) || empty($title)) {
    echo json_encode([
        "success" => false,
        "message" => "Missing parameters"
    ]);
    exit;
}

$stmt = $conn->prepare(
    "DELETE FROM complaints WHERE patient_id = ? AND title = ?"
);
$stmt->bind_param("ss", $patient_id, $title);

if ($stmt->execute()) {
    echo json_encode([
        "success" => true,
        "message" => "Complaint deleted successfully"
    ]);
} else {
    echo json_encode([
        "success" => false,
        "message" => "Failed to delete complaint"
    ]);
}

$stmt->close();
$conn->close();
