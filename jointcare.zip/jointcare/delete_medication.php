<?php
require_once "db_connect.php";
header("Content-Type: application/json; charset=UTF-8");

$data = json_decode(file_get_contents("php://input"), true);

$patient_id = $data["patient_id"] ?? "";
$name       = $data["name"] ?? "";
$dose       = $data["dose"] ?? "";
$period     = $data["period"] ?? "";

if (
    empty($patient_id) ||
    empty($name) ||
    empty($dose) ||
    empty($period)
) {
    echo json_encode([
        "success" => false,
        "message" => "Missing parameters"
    ]);
    exit;
}

$stmt = $conn->prepare(
    "DELETE FROM medications
     WHERE patient_id = ?
       AND name = ?
       AND dose = ?
       AND period = ?"
);

$stmt->bind_param(
    "ssss",
    $patient_id,
    $name,
    $dose,
    $period
);

if ($stmt->execute()) {
    echo json_encode([
        "success" => true,
        "message" => "Medication deleted"
    ]);
} else {
    echo json_encode([
        "success" => false,
        "message" => "Delete failed"
    ]);
}

$stmt->close();
$conn->close();
?>
