<?php
require_once "db_connect.php";
header("Content-Type: application/json; charset=UTF-8");

$data = json_decode(file_get_contents("php://input"), true);
$id = $data["id"] ?? "";

if (empty($id)) {
    echo json_encode([
        "success" => false,
        "message" => "Missing id"
    ]);
    exit;
}

$stmt = $conn->prepare(
    "DELETE FROM referrals WHERE id = ?"
);
$stmt->bind_param("i", $id);

if ($stmt->execute() && $stmt->affected_rows > 0) {
    echo json_encode([
        "success" => true,
        "message" => "Referral deleted"
    ]);
} else {
    echo json_encode([
        "success" => false,
        "message" => "Referral not found"
    ]);
}

$stmt->close();
$conn->close();
