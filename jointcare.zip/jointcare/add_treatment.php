<?php
header("Content-Type: application/json");
require_once "db_config.php";

try {
    // Read JSON body
    $data = json_decode(file_get_contents("php://input"), true);

    if (!$data) {
        throw new Exception("Invalid JSON payload");
    }

    // Required fields
    $required = [
        "patient_id",
        "name",
        "dose",
        "route",
        "frequency_number",
        "frequency_text",
        "duration"
    ];

    foreach ($required as $field) {
        if (!isset($data[$field]) || trim($data[$field]) === "") {
            throw new Exception("Field '{$field}' is required");
        }
    }

    // Prepare SQL (MATCHES DB COLUMNS)
    $stmt = $mysqli->prepare("
        INSERT INTO treatments
        (patient_id, medicine_name, dose, route, frequency_number, frequency_text, duration_weeks)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");

    if (!$stmt) {
        throw new Exception("Prepare failed: " . $mysqli->error);
    }

    // Bind params
    $stmt->bind_param(
        "sssssss",
        $data["patient_id"],
        $data["name"],              // → medicine_name
        $data["dose"],
        $data["route"],
        $data["frequency_number"],
        $data["frequency_text"],
        $data["duration"]           // → duration_weeks
    );

    // Execute
    if (!$stmt->execute()) {
        throw new Exception("Execute failed: " . $stmt->error);
    }

    echo json_encode([
        "success" => true,
        "message" => "Treatment added successfully"
    ]);

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "error" => $e->getMessage()
    ]);
}
