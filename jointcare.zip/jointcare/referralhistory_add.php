<?php
require_once "db_connect.php";
header("Content-Type: application/json; charset=UTF-8");

$data = json_decode(file_get_contents("php://input"), true);
$patient_id = $data["patient_id"] ?? "";
$message = $data["message"] ?? "";

if (empty($patient_id) || empty($message)) {
    echo json_encode([
        "success" => false,
        "message" => "Missing parameters"
    ]);
    exit;
}

$stmt = $conn->prepare(
    "INSERT INTO referrals (patient_id, message) VALUES (?, ?)"
);
$stmt->bind_param("ss", $patient_id, $message);

if ($stmt->execute()) {
    echo json_encode(["success" => true]);
} else {
    echo json_encode(["success" => false]);
}

$stmt->close();
$conn->close();
