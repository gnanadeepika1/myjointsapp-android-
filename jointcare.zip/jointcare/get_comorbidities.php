<?php
header('Content-Type: application/json; charset=UTF-8');
require_once 'db_connect.php';

$data = json_decode(file_get_contents("php://input"), true);
$patient_id = trim($data['patient_id'] ?? '');

if ($patient_id === '') {
    echo json_encode([
        "success" => false,
        "message" => "patient_id required"
    ]);
    exit;
}

$stmt = $conn->prepare(
    "SELECT id, title, text
     FROM comorbidities
     WHERE patient_id = ?
     ORDER BY created_at DESC"
);

$stmt->bind_param("s", $patient_id);
$stmt->execute();
$result = $stmt->get_result();

$rows = [];
while ($row = $result->fetch_assoc()) {
    $rows[] = $row;
}

echo json_encode([
    "success" => true,
    "comorbidities" => $rows
]);

$stmt->close();
$conn->close();
