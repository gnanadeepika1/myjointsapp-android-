<?php
require_once "db_connect.php";
header("Content-Type: application/json; charset=UTF-8");

$data = json_decode(file_get_contents("php://input"), true);
$patient_id = $data["patient_id"] ?? "";

if (empty($patient_id)) {
    echo json_encode(["success" => false]);
    exit;
}

$where = [];
$params = [];
$types = "";

foreach ($data as $k => $v) {
    if ($k !== "patient_id" && $v !== "") {
        $where[] = "$k = ?";
        $params[] = $v;
        $types .= "s";
    }
}

$sql = "DELETE FROM investigations WHERE patient_id = ?";
$types = "s" . $types;
$params = array_merge([$patient_id], $params);

if ($where) {
    $sql .= " AND " . implode(" AND ", $where);
}

$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();

echo json_encode(["success" => true]);
$stmt->close();
$conn->close();
?>
