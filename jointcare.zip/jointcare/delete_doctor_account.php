<?php
header('Content-Type: application/json; charset=utf-8');
require_once "db_connect.php";

$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data['doctor_id']) || empty($data['doctor_id'])) {
    echo json_encode([
        "success" => false,
        "message" => "Doctor ID missing"
    ]);
    exit;
}

$doctor_id = $conn->real_escape_string($data['doctor_id']);

$sql = "DELETE FROM doctors WHERE doctor_id = '$doctor_id'";

if ($conn->query($sql)) {
    if ($conn->affected_rows > 0) {
        echo json_encode([
            "success" => true,
            "message" => "Doctor account deleted"
        ]);
    } else {
        echo json_encode([
            "success" => false,
            "message" => "No account found"
        ]);
    }
} else {
    echo json_encode([
        "success" => false,
        "message" => $conn->error
    ]);
}

$conn->close();
