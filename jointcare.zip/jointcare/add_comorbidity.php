<?php
header('Content-Type: application/json; charset=UTF-8');
require_once 'db_connect.php';

$data = json_decode(file_get_contents("php://input"), true);

$patient_id = trim($data['patient_id'] ?? '');
$doctor_id  = trim($data['doctor_id'] ?? '');
$title      = trim($data['title'] ?? 'Comorbidity');
$text       = trim($data['text'] ?? '');

if ($patient_id === '' || $doctor_id === '' || $text === '') {
    echo json_encode([
        "success" => false,
        "message" => "Missing required fields"
    ]);
    exit;
}

$stmt = $conn->prepare(
    "INSERT INTO comorbidities (patient_id, doctor_id, title, text)
     VALUES (?, ?, ?, ?)"
);

$stmt->bind_param("ssss", $patient_id, $doctor_id, $title, $text);

if ($stmt->execute()) {
    echo json_encode([
        "success" => true
    ]);
} else {
    echo json_encode([
        "success" => false,
        "message" => $stmt->error
    ]);
}

$stmt->close();
$conn->close();
