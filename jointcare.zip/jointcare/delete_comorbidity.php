<?php
header('Content-Type: application/json; charset=UTF-8');
require_once 'db_connect.php';

$data = json_decode(file_get_contents("php://input"), true);
$id = intval($data['id'] ?? 0);

if ($id <= 0) {
    echo json_encode([
        "success" => false,
        "message" => "Invalid id"
    ]);
    exit;
}

$stmt = $conn->prepare("DELETE FROM comorbidities WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();

echo json_encode([
    "success" => true
]);

$stmt->close();
$conn->close();
